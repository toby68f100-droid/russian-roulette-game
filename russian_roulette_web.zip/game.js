
/* Russian Roulette — Browser Edition
   1 human player + 5 NPCs.
   Mechanics:
   - 6-chamber revolver, 1 bullet placed randomly each new round.
   - Players take turns; if you get shot you die.
   - Winner (last alive) gets $1000 (fake).
   - Chance card costs $100: outcomes -> Skip turn, Shoot another player, Shoot yourself twice.
*/

const playersEl = document.getElementById('players');
const logEl = document.getElementById('log');
const statusEl = document.getElementById('status');
const btnPull = document.getElementById('btn-pull');
const btnChance = document.getElementById('btn-chance');
const btnNew = document.getElementById('btn-new');

let game = null;

function Player(name, isNPC=false){
  this.name = name;
  this.isNPC = isNPC;
  this.isAlive = true;
  this.money = 0;
}

function Game(){
  this.players = [];
  this.currentIndex = 0;
  this.bulletPos = 0; // 0..5
  this.pointer = 0; // current chamber pointer 0..5
  this.running = false;
  this.init();
}

Game.prototype.init = function(){
  this.players = [];
  this.players.push(new Player('You', false));
  for(let i=1;i<=5;i++) this.players.push(new Player('NPC '+i, true));
  this.currentIndex = 0;
  this.resetChamber();
  this.running = true;
  log('New game started.');
  render();
}

Game.prototype.resetChamber = function(){
  this.bulletPos = Math.floor(Math.random()*6);
  this.pointer = Math.floor(Math.random()*6);
  log('A single round is loaded (6-chamber).');
}

Game.prototype.aliveCount = function(){ return this.players.filter(p=>p.isAlive).length; }
Game.prototype.aliveList = function(){ return this.players.filter(p=>p.isAlive); }

Game.prototype.advanceTurn = function(){
  if(!this.running) return;
  // move to next alive player
  let idx = this.currentIndex;
  for(let i=1;i<=this.players.length;i++){
    let cand = (idx + i) % this.players.length;
    if(this.players[cand].isAlive){
      this.currentIndex = cand;
      return;
    }
  }
}

Game.prototype.pullTrigger = function(player){
  if(!player.isAlive) return `${player.name} is already dead.`;
  log(`${player.name} pulls the trigger...`);
  // check shot
  let result = '';
  if(this.pointer === this.bulletPos){
    player.isAlive = false;
    result = `${player.name} got shot!`;
    // reset chamber for next round (but keep game running if >1 alive)
    this.resetChamber();
  } else {
    result = `${player.name} survived.`;
    this.pointer = (this.pointer + 1) % 6;
  }
  log(result);
  return result;
}

Game.prototype.drawChance = function(player){
  if(player.money < 100) return `${player.name} doesn't have $100 to draw a Chance Card.`;
  player.money -= 100;
  log(`${player.name} spends $100 to draw a Chance Card...`);
  const outcome = Math.floor(Math.random()*3); // 0,1,2
  if(outcome===0){
    log('Chance: Skip next turn.');
    return 'skip';
  } else if(outcome===1){
    log('Chance: Shoot another player.');
    return 'shoot_other';
  } else {
    log('Chance: Shoot yourself twice.');
    // perform two pulls (if alive after first)
    this.pullTrigger(player);
    if(player.isAlive) this.pullTrigger(player);
    return 'done';
  }
}

Game.prototype.checkWinner = function(){
  const alive = this.aliveList();
  if(alive.length === 1){
    const winner = alive[0];
    winner.money += 1000;
    log(`Game over — ${winner.name} is the last alive and wins $1,000!`);
    this.running = false;
    render();
    return winner;
  }
  return null;
}

function log(txt){
  const p = document.createElement('div');
  p.textContent = `${new Date().toLocaleTimeString()} — ${txt}`;
  logEl.prepend(p);
}

function render(){
  // players
  playersEl.innerHTML = '';
  game.players.forEach((p, idx)=>{
    const div = document.createElement('div');
    div.className = 'player' + (p.isAlive? '' : ' dead');
    const name = document.createElement('div');
    name.className='p-name';
    name.textContent = p.name + (idx===game.currentIndex && p.isAlive ? ' ⬅️' : '');
    const money = document.createElement('div');
    money.className='p-money';
    money.textContent = `$${p.money}`;
    div.appendChild(name);
    div.appendChild(money);
    playersEl.appendChild(div);
  });

  statusEl.innerHTML = `<div><strong>Chamber pointer:</strong> ${game.pointer+1} / 6 — <strong>Alive:</strong> ${game.aliveCount()}</div>`;
  // buttons state: only enable for human's turn and if game running
  const current = game.players[game.currentIndex];
  const isHumanTurn = current && !current.isNPC && current.isAlive && game.running;
  btnPull.disabled = !isHumanTurn;
  btnChance.disabled = !isHumanTurn;
  btnNew.disabled = false;
}

function humanPull(){
  const player = game.players[game.currentIndex];
  if(!player || player.isNPC) return;
  game.pullTrigger(player);
  const winner = game.checkWinner();
  if(!winner){
    // NPCs take turns automatically until next human turn or game ends
    game.advanceTurn();
    runNPCsUntilHumanOrEnd();
  }
  render();
}

function humanChance(){
  const player = game.players[game.currentIndex];
  if(!player || player.isNPC) return;
  const outcome = game.drawChance(player);
  if(outcome === 'skip'){
    // skip sets current to next player
    game.advanceTurn();
  } else if(outcome === 'shoot_other'){
    // show prompt to choose target
    const targets = game.players.map((p, i)=>({p,i})).filter(x=>x.p.isAlive && x.i !== game.currentIndex);
    if(targets.length === 0){ log('No targets available.'); }
    else {
      // for browser quickness: choose random target (human can be allowed to choose, but simplified)
      const choice = targets[Math.floor(Math.random()*targets.length)];
      log(`${game.players[game.currentIndex].name} must shoot ${choice.p.name} (by chance card).`);
      // resolve shot as if they pulled the trigger at that target
      // we simulate: target pulls trigger (same chamber rules)
      game.pullTrigger(choice.p);
    }
    game.advanceTurn();
  } else {
    // outcome already executed (self-shoot twice)
    // if player died, no extra action
    game.advanceTurn();
  }
  const winner = game.checkWinner();
  if(!winner) runNPCsUntilHumanOrEnd();
  render();
}

function runNPCsUntilHumanOrEnd(){
  // Let NPCs take deterministic simple AI turns until it's human's turn or game ends
  let safety = 0;
  while(game.running && game.players[game.currentIndex].isNPC){
    const npc = game.players[game.currentIndex];
    // simple AI: if has >=100 and random < 0.25, draw chance; else pull trigger
    const rnd = Math.random();
    if(npc.money >= 100 && rnd < 0.22){
      const res = game.drawChance(npc);
      if(res === 'skip'){
        game.advanceTurn();
      } else if(res === 'shoot_other'){
        // choose random other
        const targets = game.players.filter(p=>p.isAlive && p !== npc);
        if(targets.length>0){
          const target = targets[Math.floor(Math.random()*targets.length)];
          log(`${npc.name} (AI) shoots ${target.name} due to Chance Card.`);
          game.pullTrigger(target);
        }
        game.advanceTurn();
      } else {
        // done (self-shoot executed inside drawChance)
        game.advanceTurn();
      }
    } else {
      // pull trigger
      game.pullTrigger(npc);
      game.advanceTurn();
    }
    const winner = game.checkWinner();
    if(winner) break;
    safety++;
    if(safety>100) break;
  }
  render();
}

// Event handlers
btnPull.addEventListener('click', humanPull);
btnChance.addEventListener('click', humanChance);
btnNew.addEventListener('click', ()=>{ game = new Game(); render(); });

// init
game = new Game();
render();
