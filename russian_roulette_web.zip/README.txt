Russian Roulette — Browser Edition
Files:
- index.html : main HTML file
- styles.css : basic styling
- game.js : game logic (JavaScript)

How to play:
1. Download and unzip the package.
2. Open index.html in your Android phone's browser (Chrome recommended).
3. Play: you are "You" and play against 5 NPCs.
4. Winner earns $1,000 fake money. Chance card costs $100 and may Skip your turn, Make you shoot another player, or make you shoot yourself twice.

Notes:
- This is a browser-based version for quick play. If you want a native Android APK or the full Android Studio project, reply and I can provide a starter Android project you can import into Android Studio.
- This game contains simulated "gun" mechanics as game fiction. It's non-graphic and all in-browser.

Enjoy!
